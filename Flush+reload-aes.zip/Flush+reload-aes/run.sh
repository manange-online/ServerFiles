#!/bin/bash

# Path to the newspy.cpp file
NEWSY_FILE="newspy.cpp"

# Path to the combinations file
COMB_FILE="updated_combinations.txt"

# Temporary file to hold modified newspy.cpp
TEMP_FILE="newspy_temp.cpp"

# Read each line from updated_combinations.txt
line_num=1
while IFS= read -r base_t_line
do
    echo "Running attack with combination $line_num"

    # Replace the 'int Base_T[4] = {...};' line in newspy.cpp
    # Assuming the line containing Base_T is unique in newspy.cpp
    sed "s|int Base_T\[4\] = {.*};|$base_t_line|" "$NEWSY_FILE" > "$TEMP_FILE"
    
    # Replace the original file with the temporary modified file
    mv "$TEMP_FILE" "$NEWSY_FILE"
    
    # Compile newspy.cpp
    sudo g++ -o newspy newspy.cpp -I/root/Flush+reload-aes/openssl_installed/include -L/root/Flush+reload-aes/openssl_installed/lib -lcrypto -lpthread -ldl -static
    
    # Run the attack
    sudo ./newspy
    
    echo "Completed attack with combination $line_num"
    ((line_num++))
done < "$COMB_FILE"

echo "All combinations tested."

