#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "/home/mahreen/Downloads/flush-reload_openssl/include/openssl/aes.h"
#include <fcntl.h>
#include <sched.h>
#include <sys/mman.h>
#include "cacheutils.h"
#include <map>
#include <iostream>
#include <fstream>
#include <iomanip>

int main() {
    int Base_T[4] = {0x10ba80, 0x10b280, 0x10aa80, 0x10a280};
    std::ofstream outfile("updated_combinations.txt");

    if (!outfile.is_open()) {
        std::cerr << "Error opening file." << std::endl;
        return 1;
    }

    // Iterate from 0x0 to 0xFF, updating all elements of Base_T with the same offset
    for (int offset = 0; offset < 256; offset++) {
        int updated_T[4] = {
            Base_T[0] + offset*8,
            Base_T[1] + offset*8,
            Base_T[2] + offset*8,
            Base_T[3] + offset*8
        };

        // Write the updated array to the file in the specified format
        outfile << "int Base_T[4] = { "
                << "0x" << std::hex << std::setw(6) << std::setfill('0') << updated_T[0] << ", "
                << "0x" << std::setw(6) << updated_T[1] << ", "
                << "0x" << std::setw(6) << updated_T[2] << ", "
                << "0x" << std::setw(6) << updated_T[3] << " };\n";
    }

    outfile.close();
    std::cout << "Combinations saved to updated_combinations.txt" << std::endl;
    return 0;
}
